import { supabase } from "./supabaseClient.js";

const form = document.getElementById("curso-form");
const tabla = document.getElementById("lista-cursos-body");

// Inputs
const idInput = document.getElementById("id");
const profesorInput = document.getElementById("profesor_asignado");
const nombreInput = document.getElementById("nombre");
const creditosInput = document.getElementById("creditos");

let idEditar = null; // Variable para saber si estamos editando

// ------------------------------------------------------------
// 1. EVENT DELEGATION (La solución a tus botones)
// ------------------------------------------------------------
tabla.addEventListener("click", async (e) => {
  // A) Botón ELIMINAR
  if (e.target.classList.contains("btn-delete")) {
    const id = e.target.getAttribute("data-id");
    if (confirm(`¿Seguro que deseas eliminar el curso ${id}?`)) {
      const { error } = await supabase.from("cursos").delete().eq("id", id);
      if (error) alert("Error al eliminar: " + error.message);
      else cargar(); // Recargar tabla
    }
  }

  // B) Botón EDITAR
  if (e.target.classList.contains("btn-edit")) {
    const id = e.target.getAttribute("data-id");
    cargarDatosParaEditar(id);
  }
});

// ------------------------------------------------------------
// 2. FUNCIÓN PARA CARGAR DATOS EN EL FORMULARIO
// ------------------------------------------------------------
async function cargarDatosParaEditar(id) {
  const { data, error } = await supabase
    .from("cursos")
    .select("*")
    .eq("id", id)
    .single();

  if (error || !data) {
    alert("No se pudo cargar la información para editar.");
    return;
  }

  // Rellenar formulario
  idInput.value = data.id;
  profesorInput.value = data.profesor_asignado;
  nombreInput.value = data.nombre;
  creditosInput.value = data.creditos;

  // Bloquear ID (no se debe editar la clave primaria)
  idInput.disabled = true;
  idEditar = id; // Activamos modo edición
}

// ------------------------------------------------------------
// 3. GUARDAR (Crear o Actualizar)
// ------------------------------------------------------------
if (form) {
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const datos = {
      id: idInput.value,
      profesor_asignado: profesorInput.value,
      nombre: nombreInput.value,
      creditos: creditosInput.value
    };

    let error = null;

    if (idEditar) {
      // --- UPDATE ---
      const { error: updateError } = await supabase
        .from("cursos")
        .update({
          profesor_asignado: datos.profesor_asignado,
          nombre: datos.nombre,
          creditos: datos.creditos
        })
        .eq("id", idEditar);
      error = updateError;
    } else {
      // --- INSERT ---
      const { error: insertError } = await supabase.from("cursos").insert([datos]);
      error = insertError;
    }

    if (error) {
      alert("Error al guardar: " + error.message);
      return;
    }

    // Limpiar
    form.reset();
    idEditar = null;
    idInput.disabled = false;
    cargar();
  });
}

// ------------------------------------------------------------
// 4. CARGAR TABLA
// ------------------------------------------------------------
async function cargar() {
  const { data, error } = await supabase
    .from("cursos")
    .select("*")
    .order("id", { ascending: true });

  if (error) return console.error(error);

  // Construimos todo el HTML en una variable primero (más eficiente)
  let html = "";
  data.forEach((item) => {
    html += `
      <tr>
        <td>${item.id}</td>
        <td>${item.profesor_asignado}</td>
        <td>${item.nombre}</td>
        <td>${item.creditos}</td>
        <td>
            <button class="btn-edit" data-id="${item.id}">Editar</button>
            <button class="btn-delete" data-id="${item.id}">Eliminar</button>
        </td>
      </tr>
    `;
  });
  tabla.innerHTML = html;
}

// Iniciar carga
cargar();