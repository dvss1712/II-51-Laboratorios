import { supabase } from "./supabaseClient.js";

const form = document.getElementById("estudiante-form");

const idInput = document.getElementById("id");
const nombreInput = document.getElementById("nombreCompleto"); // Nota: ID en HTML es nombreCompleto
const emailInput = document.getElementById("email");
const carreraInput = document.getElementById("carrera");

const tabla = document.getElementById("lista-estudiantes-body");

let idEditar = null;

if (form) {
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const datos = {
      id: idInput.value,
      nombre_completo: nombreInput.value, // Columna en Supabase
      email: emailInput.value,
      carrera: carreraInput.value
    };

    let error = null;

    if (idEditar) {
      // UPDATE
      const { error: updateError } = await supabase
        .from("estudiantes")
        .update({
          nombre_completo: datos.nombre_completo,
          email: datos.email,
          carrera: datos.carrera
        })
        .eq("id", idEditar);
      error = updateError;
    } else {
      // INSERT
      const { error: insertError } = await supabase.from("estudiantes").insert([datos]);
      error = insertError;
    }

    if (error) {
      alert("Error: " + error.message);
      return;
    }

    form.reset();
    idEditar = null;
    idInput.disabled = false;
    cargar();
  });
}

async function cargar() {
  const { data } = await supabase.from("estudiantes").select("*").order("id", { ascending: true });
  tabla.innerHTML = "";

  data.forEach((e) => {
    tabla.innerHTML += `
      <tr>
        <td>${e.id}</td>
        <td>${e.nombre_completo}</td>
        <td>${e.email}</td>
        <td>${e.carrera}</td>
        <td>
            <button class="btn-edit" data-id="${e.id}">Editar</button>
            <button class="btn-delete" data-id="${e.id}">Eliminar</button>
        </td>
      </tr>
    `;
  });
  agregarEventosBotones();
}

function agregarEventosBotones() {
  document.querySelectorAll(".btn-delete").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.getAttribute("data-id");
      if (confirm("¿Eliminar?")) {
        const { error } = await supabase.from("estudiantes").delete().eq("id", id);
        if (!error) cargar();
      }
    });
  });

  document.querySelectorAll(".btn-edit").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.getAttribute("data-id");
      const { data } = await supabase.from("estudiantes").select("*").eq("id", id).single();
      
      if(data) {
          idInput.value = data.id;
          nombreInput.value = data.nombre_completo;
          emailInput.value = data.email;
          carreraInput.value = data.carrera;
          
          idInput.disabled = true;
          idEditar = data.id;
      }
    });
  });
}

cargar();